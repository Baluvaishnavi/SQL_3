package com.mrurespect.employeeapp;

import com.mrurespect.employeeapp.dao.RoleDao;
import com.mrurespect.employeeapp.entity.Role;
import com.mrurespect.employeeapp.service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class EmployeeAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeAppApplication.class, args);
    }

    @Bean
    public CommandLineRunner initData(UserService userService, RoleDao roleDao) {
        return args -> {
            // 1. Ensure all Roles exist in the database
            String[] roles = {"ROLE_EMPLOYEE", "ROLE_MANAGER", "ROLE_ADMIN"};
            
            for (String roleName : roles) {
                if (roleDao.findRoleByName(roleName) == null) {
                    roleDao.save(new Role(roleName));
                }
            }
            
            // 2. Create the 'superadmin' account if it doesn't exist
            if (userService.findByUserName("superadmin") == null) {
                // IMPORTANT: If 'createNewUser' shows a red error, see the fix below!
                userService.createNewUser("superadmin", "pass123", "admin@mru.com", "ROLE_ADMIN");
                System.out.println(">>> SUCCESS: Superadmin created. Login with: superadmin / pass123");
            }
        };
    }
}