package com.mrurespect.employeeapp.controller;
import com.mrurespect.employeeapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller
@RequestMapping("/admin")
public class AdminController {
    private final UserService userService;
    @Autowired
    public AdminController(UserService userService) {
        this.userService = userService;
    }
    @GetMapping("/users")
    public String listUsers(Model theModel) {
        theModel.addAttribute("users", userService.findAll());
        return "list-users";
    }
    @PostMapping("/updateRole")
    public String updateRole(@RequestParam("userName") String userName, 
                             @RequestParam("roleName") String roleName) {
        userService.updateUserRole(userName, roleName);
        return "redirect:/admin/users";
    }
}