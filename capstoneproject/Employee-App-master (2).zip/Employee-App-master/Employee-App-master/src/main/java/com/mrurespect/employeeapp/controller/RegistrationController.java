package com.mrurespect.employeeapp.controller;

import com.mrurespect.employeeapp.entity.User;
import com.mrurespect.employeeapp.security.WebUser;
import com.mrurespect.employeeapp.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/register")
public class RegistrationController {

    private final UserService userService;

    @Autowired
    public RegistrationController(UserService userService) {
        this.userService = userService;
    }

    @InitBinder
    public void initBinder(WebDataBinder dataBinder) {
        StringTrimmerEditor stringTrimmerEditor = new StringTrimmerEditor(true);
        dataBinder.registerCustomEditor(String.class, stringTrimmerEditor);
    }

    @GetMapping("/showRegistrationForm")
    public String showRegistrationForm(Model theModel) {
        theModel.addAttribute("webUser", new WebUser());
        return "register"; 
    }

    @PostMapping("/processRegistrationForm")
    public String processRegistrationForm(
            @Valid @ModelAttribute("webUser") WebUser webUser,
            BindingResult bindingResult,
            HttpSession session,
            Model model) {

        if (bindingResult.hasErrors()) {
            return "register";
        }

        User existing = userService.findByUserName(webUser.getUsername());
        if (existing != null) {
            model.addAttribute("webUser", new WebUser());
            model.addAttribute("registrationError", "Username already exists.");
            return "register";
        }

        userService.save(webUser);
        session.setAttribute("user", webUser);

        return "register-confirmation";
    }

    // --- NEW: UI Logic to Manage Roles ---

    @GetMapping("/listUsers")
    public String listUsers(Model theModel) {
        // Fetch all users from the database
        List<User> theUsers = userService.findAll();
        theModel.addAttribute("users", theUsers);
        
        // This will return a new page: list-users.html
        return "list-users";
    }

    @PostMapping("/updateRole")
    public String updateRole(@RequestParam("userName") String userName, 
                             @RequestParam("roleName") String roleName) {
        
        // We call the service to update the role through the UI
        userService.updateUserRole(userName, roleName);
        
        return "redirect:/register/listUsers";
    }
}