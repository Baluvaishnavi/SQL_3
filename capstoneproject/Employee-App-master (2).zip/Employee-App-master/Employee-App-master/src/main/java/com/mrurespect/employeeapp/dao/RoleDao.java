package com.mrurespect.employeeapp.dao;

import com.mrurespect.employeeapp.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleDao extends JpaRepository<Role, Long> {
    
    // Spring Data JPA automatically writes the SQL for this based on the name!
    Role findRoleByName(String name);
}