package com.mrurespect.employeeapp.dao;

import com.mrurespect.employeeapp.entity.User;
import java.util.List;

public interface UserDao {
    User findByUserName(String userName);
    void save(User user);
    List<User> findAll(); // This connects the Admin UI list to the DB
}