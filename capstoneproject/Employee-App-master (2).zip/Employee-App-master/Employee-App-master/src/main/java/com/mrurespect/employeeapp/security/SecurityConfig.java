package com.mrurespect.employeeapp.security;

import com.mrurespect.employeeapp.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

@Configuration
public class SecurityConfig {

    // NOTE: The conflicting UserDetailsManager method (for john, mary, susan) has been removed.
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http, AuthenticationSuccessHandler customAuthenticationSuccessHandler) throws Exception {
	    http.authorizeHttpRequests(configurer ->
	        configurer
	            // 1. PUBLIC PATHS FIRST (The Fix for your 400 error)
	            .requestMatchers("/register/**").permitAll()
	            .requestMatchers("/showMyLoginPage").permitAll()
	            .requestMatchers("/css/**", "/js/**", "/images/**").permitAll() // Permit static resources

	            // 2. PROTECTED PATHS
	            .requestMatchers(HttpMethod.GET, "/", "/employees/list").hasAnyRole("EMPLOYEE", "MANAGER", "ADMIN")
	            .requestMatchers(HttpMethod.GET, "/admin/users").hasRole("ADMIN")
	            .requestMatchers(HttpMethod.GET, "/employees/showFormForAdd").hasAnyRole("MANAGER", "ADMIN")
	            .requestMatchers(HttpMethod.POST, "/employees/save").hasAnyRole("MANAGER", "ADMIN")
	            .requestMatchers(HttpMethod.GET, "/employees/delete").hasRole("ADMIN")
	            .requestMatchers(HttpMethod.GET, "/employees/enableChange/**").hasAnyRole("MANAGER", "ADMIN")
	            
	            // Optional REST rules
	            .requestMatchers(HttpMethod.PUT, "/employees/employees").hasRole("ADMIN")
	            .requestMatchers(HttpMethod.DELETE, "/employees/employees/**").hasRole("ADMIN")

	            // 3. CATCH-ALL
	            .anyRequest().authenticated()
	    ).formLogin(form ->
	        form
	            .loginPage("/showMyLoginPage")
	            .loginProcessingUrl("/authenticateTheUser")
	            .successHandler(customAuthenticationSuccessHandler)
	            .permitAll()
	    ).logout(logout ->
	        logout.permitAll()
	    ).exceptionHandling(configurer ->
	        configurer.accessDeniedPage("/access-denied")
	    );

	    // Disable CSRF for development if you're having issues with POST forms
	    http.csrf(csrf -> csrf.disable());

	    return http.build();
	}
  

    // Define the AuthenticationManager explicitly (required for some older Spring Security configurations)
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
        return configuration.getAuthenticationManager();
    }

    @Bean
    public DaoAuthenticationProvider provider(UserService userService) {
        // Create a new DAO authentication provider
        DaoAuthenticationProvider auth = new DaoAuthenticationProvider();

        // Set the user details service (to fetch user from the DB)
        auth.setUserDetailsService(userService);

        // Set the password encoder (to match the DB BCrypt hash)
        auth.setPasswordEncoder(passwordEncoder());

        return auth;
    }

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}