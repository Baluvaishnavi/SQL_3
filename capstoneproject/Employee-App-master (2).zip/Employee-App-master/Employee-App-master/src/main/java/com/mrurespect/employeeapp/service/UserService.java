package com.mrurespect.employeeapp.service;

import com.mrurespect.employeeapp.entity.User;
import com.mrurespect.employeeapp.security.WebUser;
import org.springframework.security.core.userdetails.UserDetailsService;
import java.util.List;

public interface UserService extends UserDetailsService {

    void save(WebUser webUser); 

    User findByUserName(String userName);

    List<User> findAll();

    void updateUserRole(String userName, String roleName);

    // FIX: Add this line so CommandLineRunner can see it
    void createNewUser(String username, String password, String email, String roleName);
}