package com.mrurespect.employeeapp.service;

import com.mrurespect.employeeapp.dao.RoleDao;
import com.mrurespect.employeeapp.dao.UserDao;
import com.mrurespect.employeeapp.entity.Role;
import com.mrurespect.employeeapp.entity.User;
import com.mrurespect.employeeapp.security.WebUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private final UserDao userDao;
    private final RoleDao roleDao;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserServiceImpl(UserDao userDao, RoleDao roleDao, PasswordEncoder passwordEncoder) {
        this.userDao = userDao;
        this.roleDao = roleDao;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public User findByUserName(String userName) {
        return userDao.findByUserName(userName);
    }

    @Override
    public List<User> findAll() {
        return userDao.findAll();
    }

    @Override
    @Transactional
    public void save(WebUser webUser) {
        User user = new User();
        user.setUserName(webUser.getUsername());
        user.setPassword(passwordEncoder.encode(webUser.getPassword()));
        user.setFirstName(webUser.getFirstName());
        user.setLastName(webUser.getLastName());
        user.setEmail(webUser.getEmail());
        user.setEnabled(true);

        Role role = roleDao.findRoleByName("ROLE_EMPLOYEE");
        user.setRoles(Arrays.asList(role));

        userDao.save(user);
    }

    @Override
    @Transactional
    public void updateUserRole(String userName, String roleName) {
        User user = userDao.findByUserName(userName);
        if (user != null) {
            Role role = roleDao.findRoleByName(roleName);
            if (role != null) {
                user.setRoles(Arrays.asList(role));
                userDao.save(user);
            }
        }
    }

    // FIX: Added the implementation for the missing method
    @Override
    @Transactional
    public void createNewUser(String username, String password, String email, String roleName) {
        User user = new User();
        
        // Ensure this matches your User entity setter (setUserName or setUsername)
        user.setUserName(username); 
        user.setPassword(passwordEncoder.encode(password));
        user.setEmail(email);
        user.setEnabled(true);

        Role role = roleDao.findRoleByName(roleName);
        if (role != null) {
            user.setRoles(Arrays.asList(role));
        }

        userDao.save(user);
    }

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        User user = userDao.findByUserName(userName);
        if (user == null) {
            throw new UsernameNotFoundException("Invalid username or password.");
        }
        return new org.springframework.security.core.userdetails.User(user.getUserName(), 
                user.getPassword(), mapRolesToAuthorities(user.getRoles()));
    }

    private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles) {
        return roles.stream().map(role -> new SimpleGrantedAuthority(role.getName())).collect(Collectors.toList());
    }
}